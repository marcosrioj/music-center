# MusicCenter para iPhone e iPad

Extraia toda a pasta, abra ios/App/App.xcodeproj no Xcode 26 ou superior em um Mac e selecione o esquema App. A resolução inicial das dependências Swift requer internet. Escolha um simulador com iOS 16.4 ou superior e execute Run. Para instalar em aparelho físico, configure sua equipe em Signing & Capabilities.

Os quatro plugins Swift locais ficam em node_modules. Mantenha as pastas nas posições fornecidas. O aplicativo usa o mesmo projeto Supabase do painel web. Em uma instalação genérica, informe o endereço HTTPS do painel publicado na primeira abertura. Para confirmação de e-mail e recuperação de senha em aparelhos, inclua app.musiccenter.mobile://auth/callback nos Redirect URLs do projeto Supabase.

Para alterar a interface, instale Node.js 22.12 ou posterior e rode npm ci na pasta extraída. Para fixar a configuração do serviço, copie .env.example para .env.local, preencha as variáveis públicas e execute npm run ios. As migrações e a função de exclusão da conta estão em supabase.
