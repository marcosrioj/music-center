# MusicCenter para iPhone e iPad

Extraia a pasta MusicCenter-iOS inteira e abra `apps/mobile/ios/App/App.xcodeproj` no Xcode 26 ou superior, em um Mac. Selecione o esquema **App**, escolha um simulador com iOS 16.4 ou superior e execute **Run**. Para instalar no aparelho, selecione sua equipe em **Signing & Capabilities**. O Xcode precisa de internet para baixar as dependências Swift remotas na primeira abertura.

A interface compilada e os plugins Swift locais já acompanham o projeto. Mantenha `node_modules` e `apps` nas posições fornecidas. O aplicativo usa o serviço Supabase do painel. Uma compilação genérica solicita o endereço HTTPS do painel na primeira abertura.

Para alterar a interface e recompilar, abra um terminal na pasta MusicCenter-iOS, onde estão `package.json` e `package-lock.json`. Instale Node.js 22.12 ou posterior e execute `npm ci`. O código da interface está em `apps/web`. As compilações configuradas incluem na raiz um `.env` com os valores públicos do painel para que a recompilação use o mesmo serviço. Para apontar para outro painel, copie `.env.example` para `.env.local` na raiz e preencha as três variáveis públicas. Use `npm run ios` no Mac para recompilar a interface, sincronizar o projeto iOS e abri-lo no Xcode.

As migrações e a função de exclusão de conta ficam em `backend/supabase`. Para receber os links de confirmação e recuperação de senha no aplicativo, cadastre `app.musiccenter.mobile://auth/callback` entre os endereços de redirecionamento permitidos no Supabase.
